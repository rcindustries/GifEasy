# GifEasy/__init__.py

from .GifEasy import gif_easy  # Importe la fonction ou la classe gif_easy depuis GifEasy.py